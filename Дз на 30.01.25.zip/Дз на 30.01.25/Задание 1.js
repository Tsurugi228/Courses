let age = prompt("Введите ваш возраст:");
age = Number(age);

if (age >= 18) {
    alert("Вы совершеннолетний");
} else {
    alert("Вы несовершеннолетний");
}
