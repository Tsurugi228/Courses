function printNumbers() {
let start = 1;
let end = 5;
console.log("Вывод чисел от 1 до 5");
while (start <= end) {
    console.log(start);
    start++;
}

console.log("Программа завершена!");
}


printNumbers();