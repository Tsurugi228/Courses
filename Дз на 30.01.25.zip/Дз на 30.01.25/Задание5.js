let answer = prompt("Солнце — это звезда? (да/нет)").toLowerCase();

if (answer === "да") {
    alert("Правильно!");
} else if (answer === "нет") {
    alert("Неправильно, Солнце — это звезда.");
} else {
    alert("Пожалуйста, введите 'да' или 'нет'.");
}
