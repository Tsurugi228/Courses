function quiz() {
    let score = 0;

    const questions = [
        { question: "Какой цвет получается при смешении синего и жёлтого?", answer: "зелёный" },
        { question: "Сколько планет в Солнечной системе?", answer: "8" },
        { question: "Как называется столица Франции?", answer: "Париж" }
    ];

    questions.forEach(q => {
        let userAnswer = prompt(q.question).trim().toLowerCase();
        if (userAnswer === q.answer.toLowerCase()) {
            score++;
        }
    });

    alert(`Вы набрали ${score} из 3 баллов.`);
}

quiz();
