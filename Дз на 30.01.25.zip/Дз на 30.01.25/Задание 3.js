let button = document.createElement("button");
button.textContent = "Изменить фон";
button.style.fontSize = "20px";
button.style.padding = "10px 20px";
button.style.cursor = "pointer";


document.body.appendChild(button);

button.addEventListener("click", function() {
    document.body.style.backgroundColor = "blue";
});
