let number = 5;

console.log("Таблица умножения для числа 5:");

for (let i = 1; i <= 10; i++) {
    console.log(`${number} × ${i} = ${number * i}`);
}