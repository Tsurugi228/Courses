function changeText() {
    document.getElementById("message").textContent = "Вы кликнули дважды!";
}
